/*===========================
Plugins prototype
===========================*/
Framework7.prototype.plugins = {};
